package com.project.ui;


import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.util.regex.Pattern;


import com.project.bean.BankWalletBean;
import com.project.bean.TransferDetails;
import com.project.dao.BankWalletDao;
import com.project.service.BankWalletService;



public class BankWalletMain {
	Scanner sc=new Scanner(System.in);
	BankWalletService bankWalletService=new BankWalletService();
	BankWalletDao bwd=new BankWalletDao();
	
	public static void main(String[] args) {
		int ch;
		char choice;
		BankWalletMain bwmObj=new BankWalletMain();
		
		Scanner scan=new Scanner(System.in);
		do
		{
			System.out.println("*******************************Bank Wallet******************************");
			System.out.println("  1-Create Account \n 2-Show Balance \n 3-Deposit \n 4-Withdraw \n 5-Fund Transfer \n"
					+ " 6-Print Transaction \n 7-Exit ");
			System.out.println("Enter your choice : ");
			ch=scan.nextInt();
			switch(ch)
			{
			case 1:
				bwmObj.CreateAccount();
				break;
			case 2:
				bwmObj.ShowBalance();
				break;
			case 3:
				bwmObj.DepositMoney();
				break;
			case 4:
				bwmObj.WithdrawMoney();
				break;
			case 5:
				bwmObj.FundTransfer();
				break;
			case 6:
				bwmObj.PrintTransaction();
				break;
			case 7:
				System.exit(0);
				
			}
			
            System.out.print("Do you want to continue (y/n)...? : ");
			
			choice = scan.next().charAt(0);
			
			if(choice == 'y' || choice=='Y')
				continue;
			else {
				System.out.println("Thank You !");
				System.exit(0);
			}
		}
		while(ch<8);
	}
	
	public void PrintTransaction() {
		System.out.println("Enter your AccNo: ");
		long accNo=sc.nextLong();
		List<?> l=bankWalletService.printTransaction(accNo);
		Iterator<?> i=l.iterator();
		{
			while(i.hasNext())
			{
				TransferDetails td=(TransferDetails) i.next();
				System.out.println("Transaction ID: "+td.getTransId());
				System.out.println("Account from: "+td.getAccNoFrom());
				System.out.println("Account type: "+td.getTransType());
				System.out.println("Account to: "+td.getAccNoTo());
				System.out.println("Date of transaction: "+td.getDateOfTrans());
				System.out.println("Transfer amount: "+td.getTransferAmt());
				System.out.println("Balance: "+td.getBalance());
				
			}
		
		}
		
		
	}

	public void FundTransfer() {
		System.out.println("Enter Source Account Number: ");
		long sourceAccNo = sc.nextLong();
		System.out.println("Enter Destination Account Number: ");
		long destAccNo = sc.nextLong();
		System.out.println("Enter Amount to transfer: ");
		float transferAmount = amountCheck(sc.nextFloat());	
		bankWalletService.transferMoney(sourceAccNo, destAccNo, (long) transferAmount);

		
	}
	public void WithdrawMoney() {
		System.out.print("Enter Account Number: ");
		long accNo = sc.nextLong();
		System.out.print("Enter Withdraw Amount: ");
		float withdrawAmount = amountCheck(sc.nextFloat());
		//BankWalletBean bankWithdrawObj = new BankWalletBean(withdrawAmount, accNo);
		Double balance = bankWalletService.withdrawMoney(withdrawAmount, accNo);
		System.out.println("Balance is: "+balance);
	}
	public void DepositMoney() {
		System.out.println("Enter Account Number: ");
		long accNo = sc.nextLong();
		System.out.println("Enter Deposit Amount: ");
		float depAmount = amountCheck(sc.nextFloat());
		
		//BankWalletBean Obj = new BankWalletBean(accNo, depAmount);
		Double balance=bankWalletService.depositMoney(accNo,depAmount);
		System.out.println("Balance is: "+balance);
			
	}
	public void ShowBalance() {
		System.out.println("Enter Account Number: ");
		long accNo = sc.nextLong();
		//BankWalletBean Obj = new BankWalletBean(accNo);
		Double balance=bankWalletService.showBalance(accNo);
		System.out.println("Balance is: "+balance);
		
	}
	public void CreateAccount() {
		System.out.println("Enter Name: ");
		String name = nameCheck(sc.next());
		System.out.println("Enter Mobile No.: ");
		long mobNo = numberCheck(sc.nextLong());
		Random r=new Random();
		long accNo=r.nextInt(10000000);
		System.out.println("Enter Balance: "); 
		float balance = amountCheck(sc.nextFloat());
		BankWalletBean Obj = new BankWalletBean(accNo, name, mobNo, balance);
		bankWalletService.CreateAccount(Obj);
		System.out.println("Account created with Account Number: " +accNo);
	}
	public float amountCheck(float balance) {
		while(true) {
			if(balance<=0) {
				System.out.println("Amount should be greater than 0.");
				System.out.println("Enter again: ");
				balance = sc.nextInt();
			}
			else {
				return balance;
			}
		}
	}
	public long numberCheck(long mblNo) {
		while(true) {
			if(String.valueOf(mblNo).length() < 10) {
				System.out.println("Enter valid mobile number.");
				mblNo = sc.nextLong();
			}
			else {
				return mblNo;
			}
		}
	}
	public String nameCheck(String name) {
		while(true) {
			if(Pattern.matches("([A-Z])*([a-z])*", name)){
				return name;
			}
			else {
				System.out.println("Name should only have alphabets.");
				System.out.println("Enter again: ");
				name = sc.next();
			}
		}
	}

	

}































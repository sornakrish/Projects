package com.project.service;

import com.project.bean.BankWalletBean;

public interface BankServiceIF {
	public void CreateAccount(BankWalletBean Obj);
	public Double showBalance(long accNo);
	public Double depositMoney(long accNo,double depAmt);
	public Double withdrawMoney(float withdrawAmount, long accNo);
	public Double transferMoney(long sourceAccNo, long destAccNo, long transferAmount);

}

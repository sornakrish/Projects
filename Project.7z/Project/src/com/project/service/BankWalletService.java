package com.project.service;





import java.util.List;

import com.project.bean.BankWalletBean;
import com.project.dao.BankWalletDao;
import com.project.ui.BankWalletMain;

public class BankWalletService implements BankServiceIF{
	BankWalletDao bankWalletDao=new BankWalletDao();
	BankWalletBean Obj;

	
	public void CreateAccount(BankWalletBean Obj) {
		bankWalletDao.CreateAccount(Obj);
	}

	public Double showBalance(long accNo) {
		return bankWalletDao.showBalance(accNo);	
	}

	public Double depositMoney(long accNo,double depAmt) {
		return bankWalletDao.depositMoney(accNo,depAmt);
	}

	public Double withdrawMoney(float withdrawAmount, long accNo) {	
		return bankWalletDao.withdrawMoney(withdrawAmount,accNo);
	}

	public Double transferMoney(long sourceAccNo, long destAccNo, long transferAmount) {
		return bankWalletDao.transferMoney(sourceAccNo,destAccNo,transferAmount);	
	}

	public List<?> printTransaction(long accNo)
	{
		return bankWalletDao.printTransaction(accNo);
	}
}

	
	
	


























	 






package com.project.dao;



import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import com.project.bean.BankWalletBean;

import com.project.bean.TransferDetails;

public class BankWalletDao implements BankDaoIF{

    BankWalletBean Obj;
    Random rand=new Random();
	
	public HashMap<Long,BankWalletBean> hm=new HashMap<Long,BankWalletBean>();
	HashMap<TransferDetails,Long> hm1=new HashMap<TransferDetails,Long>();
	TransferDetails td;
	
	public void addCustomer(BankWalletBean Obj) {
		this.Obj=Obj;
		hm.put(Obj.getAccNo(),Obj);
		System.out.println(hm);
	}
	public void transferDetails(TransferDetails td)
	{
		this.td=td;
		
		System.out.println(hm1);
	}
	public HashMap<TransferDetails,Long> hm1()
	{
		return hm1;
	}

	public HashMap<Long,BankWalletBean> hm()
	{
		return hm;
	}
	
	public void CreateAccount(BankWalletBean Obj) {
		hm.put(Obj.getAccNo(),Obj);
		Obj=(BankWalletBean)hm.get(Obj.getAccNo());		
	}
	
	public Double showBalance(long accNo) {
		Obj=hm.get(accNo);
		double bal=Obj.getBalance();
		return bal;	
	}
	
	public Double depositMoney(long accNo, double depAmt) {
		Obj=(BankWalletBean)hm.get(accNo);
		double balance=Obj.getBalance();
		double amt=balance+depAmt;
		Obj.setBalance(amt);
		hm.put(accNo,Obj);		
		TransferDetails td=new TransferDetails();
		td.setAccNoFrom(accNo);
		td.setTransferAmt(depAmt);
		td.setTransType("deposit");
		DateTimeFormatter dt=DateTimeFormatter.ofPattern("yyyy/MM/dd");
		LocalDateTime now=LocalDateTime.now();
		td.setDateOfTrans(dt.format(now));
		td.setBalance(amt);
		hm1.put(td,(long) depAmt);
		return amt;
	}
	
	public Double withdrawMoney(float withdrawAmount, long accNo) {
		Obj=(BankWalletBean)hm.get(accNo);
		double balance=Obj.getBalance();
		double amt=balance-withdrawAmount;
		Obj.setBalance(amt);
		hm.put(accNo,Obj);
		TransferDetails td=new TransferDetails();
		td.setAccNoFrom(accNo);
		td.setTransferAmt(withdrawAmount);
		td.setTransType("withdraw");
		DateTimeFormatter dt=DateTimeFormatter.ofPattern("yyyy/MM/dd");
		LocalDateTime now=LocalDateTime.now();
		td.setDateOfTrans(dt.format(now));
		td.setBalance(amt);
		hm1.put(td,(long) withdrawAmount);
		
		return amt;
	}
	
	public Double transferMoney(long sourceAccNo, long destAccNo, long transferAmount) {
		Obj=(BankWalletBean)hm.get(sourceAccNo);
		double balance=Obj.getBalance();
		balance = balance-transferAmount;
		Obj.setBalance(balance);
		hm.put(sourceAccNo,Obj);
		
		Obj=(BankWalletBean)hm.get(destAccNo);
		double bal=Obj.getBalance();
		bal = bal+transferAmount;
		Obj.setBalance(bal);		
		hm.put(destAccNo,Obj);
		

		TransferDetails td=new TransferDetails();
		td.setAccNoFrom(sourceAccNo);
		td.setAccNoTo(destAccNo);
		td.setTransferAmt(balance);
		td.setTransType("transfer");
		DateTimeFormatter dt=DateTimeFormatter.ofPattern("yyyy/MM/dd");
		LocalDateTime now=LocalDateTime.now();
		td.setDateOfTrans(dt.format(now));
		td.setBalance(balance);
		
		hm1.put(td,(long) balance);
		
		return balance;
	}

	public List<TransferDetails> printTransaction(long accNo)
	{
		ArrayList<TransferDetails> al=new ArrayList<>(hm1.keySet());
		return al;
		
	}
		
}

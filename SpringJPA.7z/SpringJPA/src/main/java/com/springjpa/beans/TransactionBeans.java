package com.springjpa.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="TransBank")
public class TransactionBeans {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long FromAccountNo;
	@Column(name="Transaction")
	private String transaction;
	
	@ManyToOne
	@JoinColumn(name="AccountNo")
	private UserBeans ub;
	
	
	
	public UserBeans getUb() {
		return ub;
	}
	public void setUb(UserBeans ub) {
		this.ub = ub;
	}
	public String getTransaction() {
		return transaction;
	}
	public void setTransaction(String transaction) {
		this.transaction = transaction;
	}
}

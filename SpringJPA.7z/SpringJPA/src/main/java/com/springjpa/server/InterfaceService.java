//Collection Service Interface
package com.springjpa.server;

import com.springjpa.beans.UserBeans;


public interface InterfaceService {
	boolean checkAccount(long accNo2);
	boolean checkName(String userName);
	boolean checkNumber(String userNumber);
	boolean checkDob(String userDob);
	boolean checkPassword(String userPassword);
	long setBeans(String userName, long userNumber, String userDob, long userAccNo, String userPassword);
	boolean check(long accNo, String password);
	double withdraw(double amount, long accNo);
	double deposit(double amount, long accno);
	UserBeans info(long accNo);
	int transfer(long accNo1, long accNo2, float amount);
	String transactions(long accNo);
}

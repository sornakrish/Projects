package com.cg.service;

import com.cg.dao.BankDao;
import com.cg.dao.BankDaoI;
import com.cg.entities.BankEntity;


class MyException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String s1;

	MyException(String s) {
		s1 = s;
	}

	public String toString() {
		return (s1);
	}

}

public class BankService implements BankServiceI {
	BankDaoI bd = new BankDao();

	@Override
	public boolean checkName(String name) {
		int n = name.length();
		char[] ch = name.toCharArray();
		for (int i = 0; i < n; i++) {
			try {
				if (ch[i] > 64 && ch[i] < 122 && ch[0]>63 && ch[0]<90) {
					return true;
				} else {
					throw new MyException("Invalid Name");
				}
			} catch (MyException E) {
				System.out.println(E);
				return false;
			}
		}
		return false;
	}

	@Override
	public long getBalance(long accNo) {
		long acc = bd.getBalance(accNo);
		return acc;
	}

	@Override
	public String getTransaction(long accNo) {
		String str = bd.getTransaction(accNo);
		return str;
	}

	@Override
	public void setBalance(long accNo, long bal, String st)  {
		bd.setBalance(accNo, bal, st);
	}

	@Override
	public String addAccount(String name, long mobile,  String password)
	{
		BankEntity bb = new BankEntity(name, mobile, password, 1000, "Account Created Successfully\n Amount deposited Rs.1000");
		long accNo=bd.setData(bb);
		return "Congratulations "+name+"!!!,\nAccount Created Successfully.\nYour Account number is " + accNo;
	}

	@Override
	public boolean checkAccNo(long acc) {
		try {
			if (bd.checkAccNo(acc)) {

				return true;
			}

			else
				throw new MyException("Oops, You entered a wrong Account Number!");
		} catch (MyException E) {
			System.out.println(E);
		}
		return false;
	}

	@Override
	public boolean checkPass(String st,long accNo) {
		try {
			if (bd.checkPassword(st,accNo)) {

				return true;
			} else
				throw new MyException("Oops, You entered a wrong Password!");
		} catch (MyException E) {
			System.out.println(E);
		}
		return false;
	}

	@Override
	public boolean checkM(long mob) {
		// TODO Auto-generated method stub
		String s = Long.toString(mob);
		int n = s.length();
		try {
			if (n == 10) {
				return true;
			} else {
				throw new MyException("Oops, You entered a Invalid Mobile Number!\nPlease Enter a Valid Mobile Number");
			}
		} catch (MyException E) {
			System.out.println(E);
			return false;
		}

	}

	@Override
	public boolean checkP(String password) {
		// TODO Auto-generated method stub
		try {
			if (password.length() >= 6) {
				return true;
			} else {
				throw new MyException("Oops, You entered Invalid Password!\n Please Enter more than six characters");
			}
		} catch (MyException E) {
			System.out.println(E);
			return false;
		}

	}
	@Override
	public BankEntity getInfo(long accNo) {
		// TODO Auto-generated method stub
		BankEntity be=bd.getInfo(accNo);
		return be;
	}
}
